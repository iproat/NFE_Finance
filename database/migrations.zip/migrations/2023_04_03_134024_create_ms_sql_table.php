<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMsSqlTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ms_sql', function (Blueprint $table) {
            $table->increments('primary_id');
            $table->integer('local_primary_id')->nullable();
            $table->integer('evtlguid')->nullable();
            $table->string('ID')->nullable();
            $table->string('type')->nullable();
            $table->timestamp('datetime');
            $table->tinyInteger('status')->default(0);
            $table->integer('employee')->nullable();
            $table->integer('device')->nullable();
            $table->string('device_employee_id')->nullable();
            $table->text('sms_log')->nullable();
            $table->string('device_name')->nullable();
            $table->string('devuid')->nullable();
            $table->tinyInteger('live_status')->nullable();
            $table->timestamp('punching_time')->nullable();
            $table->string('inout_status')->nullable();
            $table->tinyInteger('created_by')->nullable();
            $table->tinyInteger('updated_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ms_sql');
    }
}
