<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployeeAttendancesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee_attendance', function (Blueprint $table) {
            $table->increments('employee_attendance_id');
            $table->integer('finger_print_id');
            $table->integer('employee_id');
            $table->text('face_id')->nullable();
            $table->integer('work_shift_id')->nullable();
            $table->string('latitude')->nullable();
            $table->string('longitude')->nullable();
            $table->string('uri')->nullable();
            $table->string('status')->nullable();
            $table->string('inout_status')->nullable()->comment('0-in,1-out,2-in_only');
            $table->dateTime('in_out_time');
            $table->text('check_type')->nullable();
            $table->bigInteger('verify_code')->nullable();
            $table->text('sensor_id')->nullable();
            $table->text('Memoinfo')->nullable();
            $table->text('WorkCode')->nullable();
            $table->text('sn')->nullable();
            $table->integer('UserExtFmt')->nullable();
            $table->string('mechine_sl', 20)->nullable();
            $table->tinyInteger('created_by')->nullable();
            $table->tinyInteger('updated_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee_attendance');
    }
}
